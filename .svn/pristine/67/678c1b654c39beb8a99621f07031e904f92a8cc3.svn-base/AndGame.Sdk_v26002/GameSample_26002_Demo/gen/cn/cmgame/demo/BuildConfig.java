/** Automatically generated file. DO NOT MODIFY */
package cn.cmgame.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}