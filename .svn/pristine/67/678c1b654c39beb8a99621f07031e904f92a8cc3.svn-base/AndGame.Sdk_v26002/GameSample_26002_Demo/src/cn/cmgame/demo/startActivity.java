package cn.cmgame.demo;


import android.app.ListActivity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;
import android.widget.AdapterView.OnItemClickListener;
import cn.cmgame.billing.api.BillingResult;
import cn.cmgame.billing.api.GameInterface;

public class startActivity extends ListActivity {

  private static final String[] BUTTONS = new String[]{
    "001: 隐式登录",
    "002: 显式登录",
  };


  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    setListAdapter(new ArrayAdapter<String>(this, R.layout.main_menu_item, BUTTONS));
    ListView lv = getListView();
    lv.setOnItemClickListener(new OnItemClickListener() {
      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
    	//String billingIndex = getBillingIndex(position);
    	//Toast.makeText(startActivity.this, billingIndex , Toast.LENGTH_SHORT).show();
    	if(canClick()){
        	if ((position == 0))
        	{
    			Intent intent = new Intent();
    			ComponentName component = new ComponentName(
    					"cn.cmgame.demo",
    					"cn.cmgame.demo.MainActivity");
    			intent.setComponent(component);
    			intent.setAction("android.intent.action.VIEW");
    		    Log.v("startActivity", "start startPage! ");
    			startActivity(intent);
        	}else if(position == 1){
    			Intent intent = new Intent();
    			ComponentName component = new ComponentName(
    					"cn.cmgame.demo",
    					"cn.cmgame.billing.api.GameOpenActivity");
    			intent.setComponent(component);
    			intent.setAction("android.intent.action.VIEW");
    		    Log.v("startActivity", "start startPage! ");
    			startActivity(intent);
        	}
    	}else{
    		Toast.makeText(getApplicationContext(), "请稍等片刻，so文件未加载完成", Toast.LENGTH_SHORT).show();
    	}
      }
    });
  }

  /*private String getBillingIndex(int i) {
    if (i < 9) {
      return "00" + (++i);
    } else {
      return "0" + (++i);
    }
  }*/
	public boolean canClick(){
		CmgameApplication app = (CmgameApplication) getApplication(); 
		Log.v("canClick", "getLoadState() == " + app.getLoadState());
	    return app.getLoadState();
	}
	
    @Override
    public void onResume() {
        super.onResume();
    }

  /*private void exitGame() {
    // 移动退出接口，含确认退出UI
    // 如果外放渠道（非移动自有渠道）限制不允许包含移动退出UI，可用exitApp接口（无UI退出）
    GameInterface.exit(this, new GameInterface.GameExitCallback() {
      @Override
      public void onConfirmExit() {
        startActivity.this.finish();
        System.exit(0);
      }

      @Override
      public void onCancelExit() {
        Toast.makeText(startActivity.this, "取消退出", Toast.LENGTH_SHORT).show();
      }
    });
  }

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_BACK) {
      exitGame();
      return true;
    }
    return super.onKeyDown(keyCode, event);
  }*/
}