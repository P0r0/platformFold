package cn.cmgame.demo;

import java.util.List;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
//import cn.cmgame.billing.api.GameInterface;

/**
 * Created by afwang on 13-9-17.
 */
public class CmgameApplication extends Application {

    public static boolean isLoaded = false;	
    /*static{
    	System.loadLibrary("mg20pbase");
        isLoaded = true;
    }*/
    @Override
	public void onCreate() {
		super.onCreate();
		Log.v("CmgameApplication","why call me here everytime ?");
		//String processName = getProcessName(this,
		//		android.os.Process.myPid());
		//if (processName != null) {
			//boolean defaultProcess = processName
			//		.equals("cn.cmgame.demo");
			if (!getLoadState()) {
				//必要的初始化资源操作
			      new Thread(new Runnable() {
			          @Override
			          public void run() {
			        	  System.loadLibrary("megjb");
			        	  isLoaded = true;
			        	  //savePreference();
			          }
			        }).start();
			}
		//}
	}
    /**
     * @return null may be returned if the specified process not found
    
    public static String getProcessName(Context cxt, int pid) {
        ActivityManager am = (ActivityManager) cxt.getSystemService(Context.ACTIVITY_SERVICE);
        List<RunningAppProcessInfo> runningApps = am.getRunningAppProcesses();
        if (runningApps == null) {
            return null;
        }
        for (RunningAppProcessInfo procInfo : runningApps) {
            if (procInfo.pid == pid) {
            	Log.v("CmgameApplication", "procInfo.processName == " + procInfo.processName);
                return procInfo.processName;
            }
        }
        return null;
    } */
    
    
    public void savePreference(){
    	SharedPreferences mySharedPreferences= getSharedPreferences("test", 
    			Activity.MODE_PRIVATE); 
		//实例化SharedPreferences.Editor对象（第二步） 
		SharedPreferences.Editor editor = mySharedPreferences.edit(); 
		//用putString的方法保存数据 
        editor.putBoolean("loadState", isLoaded);
		//提交当前数据 
		editor.commit(); 
    }
    
    public boolean getLoadState(){
    	//同样，在读取SharedPreferences数据前要实例化出一个SharedPreferences对象 
    	//SharedPreferences sharedPreferences= getSharedPreferences("test", 
    	//Activity.MODE_PRIVATE); 
    	// 使用getString方法获得value，注意第2个参数是value的默认值 
    	//boolean loadState = sharedPreferences.getBoolean("loadState", false);
    	return isLoaded;
    }
    public boolean setLoadState(boolean state){
    	//同样，在读取SharedPreferences数据前要实例化出一个SharedPreferences对象 
    	//SharedPreferences sharedPreferences= getSharedPreferences("test", 
    	//Activity.MODE_PRIVATE); 
    	// 使用getString方法获得value，注意第2个参数是value的默认值 
    	//boolean loadState = sharedPreferences.getBoolean("loadState", false);
    	return isLoaded = state;
    }
}
