package cn.cmgame.demo;


import android.app.ListActivity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;
import android.widget.AdapterView.OnItemClickListener;
import cn.cmgame.billing.api.BillingResult;
import cn.cmgame.billing.api.GameInterface;

public class MainActivity extends ListActivity {

  private static final String[] BUTTONS = new String[]{
    "chargePoint: 001",
    "chargePoint: 002",
    "chargePoint: 003",
    "chargePoint: 004",
    "chargePoint: 005",
    "chargePoint: 006",
    "chargePoint: 007",
    "chargePoint: 008",
    "chargePoint: 009",
    "chargePoint: 010",
    "chargePoint: 011",
    "chargePoint: 012",
    "chargePoint: 013",
    "chargePoint: 014",
    "chargePoint: 015",
    "chargePoint: 016",
    "chargePoint: 017",
    "chargePoint: 018",
    "chargePoint: 019",
    "chargePoint: 020",
    "chargePoint: 021",
    "chargePoint: 022",
    "chargePoint: 023",
    "chargePoint: 024",
  };


  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    // 初始化SDK
    Log.v("MainActivity", "before initializeApp");
    Log.v("MainActivity", "canClick() == " + canClick());
    setListAdapter(new ArrayAdapter<String>(this, R.layout.main_menu_item, BUTTONS));
  }
	public boolean canClick(){
		CmgameApplication app = (CmgameApplication) getApplication(); 
		Log.v("canClick", "getLoadState() == " + app.getLoadState());
	    return app.getLoadState();
	}
  private String getBillingIndex(int i) {
    if (i < 9) {
      return "00" + (++i);
    } else {
      return "0" + (++i);
    }
  }

  @Override
  public void onResume() {
    super.onResume();
    if(canClick()){
	    GameInterface.initializeApp(this);
	    Log.v("MainActivity", "after initializeApp");
	    // 计费结果的监听处理，合作方通常需要在收到SDK返回的onResult时，告知用户的购买结果
	    final GameInterface.IPayCallback payCallback = new GameInterface.IPayCallback() {
	      @Override
	      public void onResult(int resultCode, String billingIndex, Object obj) {
	        String result = "";
	        switch (resultCode) {
	          case BillingResult.SUCCESS:
	        	  Log.v("MainActivity", "success");
			    if((BillingResult.EXTRA_SENDSMS_TIMEOUT+"").equals(obj.toString())){
		           result = "短信计费超时";
		        }else{
				   result = "购买道具：[" + billingIndex + "] 成功！";
			    }
	            break;
	          case BillingResult.FAILED:
	        	Log.v("MainActivity", "failed");
	            result = "购买道具：[" + billingIndex + "] 失败！";
	            break;
	          default:
	            result = "购买道具：[" + billingIndex + "] 取消！";
	            break;
	        }
	        Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
	      }
	    };
	
	    ListView lv = getListView();
	    lv.setOnItemClickListener(new OnItemClickListener() {
	      public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
	    	String billingIndex = getBillingIndex(position);
	    	Toast.makeText(MainActivity.this, billingIndex , Toast.LENGTH_SHORT).show();
	    	if ((position == 0) || ( position == 9) )
	    	{
	    		GameInterface.doBilling(MainActivity.this, false, 1, billingIndex, "", payCallback);
	    	}
	    	else {
	    		GameInterface.doBilling(MainActivity.this, false, 2, billingIndex, "", payCallback);
	    	}
	      }
	    });
    }else{
			//必要的初始化资源操作
	      /*new Thread(new Runnable() {
	          @Override
	          public void run() {
	        	  System.loadLibrary("mg20pbase");
	        	  ((CmgameApplication) getApplication()).setLoadState(true);
	          }
	        }).start();*/

		Toast.makeText(getApplicationContext(), "请稍等片刻，so文件未加载完成", Toast.LENGTH_SHORT).show();
	}
  }

  private void exitGame() {
    // 移动退出接口，含确认退出UI
    // 如果外放渠道（非移动自有渠道）限制不允许包含移动退出UI，可用exitApp接口（无UI退出）
    GameInterface.exit(this, new GameInterface.GameExitCallback() {
      @Override
      public void onConfirmExit() {
    	  MainActivity.this.finish();
          System.exit(0);
      }

      @Override
      public void onCancelExit() {
        Toast.makeText(MainActivity.this, "取消退出", Toast.LENGTH_SHORT).show();
      }
    });
  }

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_BACK) {
       System.exit(0);
       return true;
    }
    return super.onKeyDown(keyCode, event);
  }
}