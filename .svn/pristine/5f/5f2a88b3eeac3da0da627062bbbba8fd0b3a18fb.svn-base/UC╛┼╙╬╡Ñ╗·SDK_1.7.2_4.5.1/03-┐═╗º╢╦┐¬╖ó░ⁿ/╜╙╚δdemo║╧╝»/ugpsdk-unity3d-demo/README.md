#使用说明 


####通过Unity3D IDE导出Eclipse工程构建
    1. 用unity IDE直接打开unity-project文件夹,将Demo.cs和SDKUnityCallbackListener.cs拖到Main Camera对象上。
    2. 参照demo修改代码
    3. File->Build settings->Google Android Project导出Android工程
    4. 通过Eclipse import刚刚导出的Android工程
    5. 把本目录(ugpsdk-unity3d-demo目录)下的src拷贝添加到导出工程的src里面。
	6. 依赖ugpsdk-integration工程，并将integration工程的"assets"目录下所有的资源文件拷贝到unity3d-demo工程
	7. 将Android工程的libs目录下的armeabi-v7a改成armeabi，或者将integration工程的armeabi目录下的so拷贝到armeabi-v7a目录


##请使用您申请的密钥文件pay.png替换demo中的pay.png,路径assets/UCPaySDK/pay.png
##运营商计费点，请参考接入文档，使用申请到的正式计费文件和计费点
