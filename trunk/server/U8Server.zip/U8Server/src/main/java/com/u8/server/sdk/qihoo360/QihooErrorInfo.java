package com.u8.server.sdk.qihoo360;

/**
 * Created by ant on 2015/4/7.
 */
public class QihooErrorInfo {

    private String error_code;
    private String error;

    public String getError_code() {
        return error_code;
    }

    public void setError_code(String error_code) {
        this.error_code = error_code;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
