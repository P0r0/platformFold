package com.u8.server.utils;

/**
 * Created by ant on 2015/12/3.
 */
public class XmlUtils {

    public static void readXML(String xml){

    }

}
