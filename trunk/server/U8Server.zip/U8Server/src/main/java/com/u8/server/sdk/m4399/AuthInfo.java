package com.u8.server.sdk.m4399;

/**
 * Created by ant on 2015/4/22.
 */
public class AuthInfo {

    private int code;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
