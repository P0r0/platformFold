package com.u8.server.sdk.downjoy;

/**
 * Created by ant on 2015/2/9.
 */
public class DownjoyExtension {

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
