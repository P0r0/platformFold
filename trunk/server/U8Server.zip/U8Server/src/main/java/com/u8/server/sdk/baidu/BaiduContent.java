package com.u8.server.sdk.baidu;

/**
 * Created by ant on 2015/2/28.
 */
public class BaiduContent {

    private long UID;

    public long getUID() {
        return UID;
    }

    public void setUID(long UID) {
        this.UID = UID;
    }
}
