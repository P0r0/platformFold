package com.u8.server.sdk.vivo;

/**
 * Created by ant on 2015/4/24.
 */
public class AuthInfo {

    private String uid;
    private String email;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
