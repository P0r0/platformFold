package com.unicom.cpdemo.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.unicom.cpdemo.commons.App;
import com.unicom.cpdemo.util.DateFomatter;
import com.unicom.cpdemo.util.MD5;
import com.unicom.cpdemo.util.PayBeanUtils;

/**
 * Unicom 支付demo
 * 访问地址为 http://{ip}:{port}/cp_demo/unicompay_callback
 */
public class UnicomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UnicomServlet() {
        super();
    }
    
    
    /**
     * 订单校验测试请求样式：
     * <?xml version="1.0" encoding="UTF-8"?><checkOrderIdReq><orderid>000000000000000000000001</orderid><signMsg>3BDD679B092CEFBF723F198795CA67D7</signMsg><usercode>15600000000</usercode><provinceid>00001</provinceid><cityid>00001</cityid></checkOrderIdReq>
     * 
     * 支付结果通知请求样式：
     * 1. 支付失败
     * <?xml version="1.0" encoding="UTF-8"?><callbackReq><orderid>000000000000000000000001</orderid><ordertime>20160630120000</ordertime><cpid>test</cpid><appid>test</appid><fid>test</fid><consumeCode>9999999999999999999999999999</consumeCode><payfee>1000</payfee><payType>4</payType><hRet>1</hRet><status>00100</status><signMsg>BB2F5AEE289C68A1F1D0C390EF6944C4</signMsg></callbackReq>
     * 
     * 2. 支付成功
     * <?xml version="1.0" encoding="UTF-8"?><callbackReq><orderid>000000000000000000000001</orderid><ordertime>20160630120000</ordertime><cpid>test</cpid><appid>test</appid><fid>test</fid><consumeCode>9999999999999999999999999999</consumeCode><payfee>1000</payfee><payType>4</payType><hRet>0</hRet><status>00000</status><signMsg>0468FD4384E7C6FDDAFC76AE4F614D35</signMsg></callbackReq>
     * 
     */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String serviceid = request.getParameter("serviceid");
	    
	    //根据serviceid，判断服务含义
	    if ("validateorderid".equals(serviceid)) {
	        
	        //校验订单
	        processValidateOrderId(request, response);
	    } else if (serviceid == null || serviceid.isEmpty())  {
	        
	        //支付结果通知
	        processPayNotify(request, response);
	    }
	    
	}

	/**
	 * 处理校验订单请求
	 * @param request
	 * @param response
	 * @throws IOException
	 */
    private void processValidateOrderId(HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        Map<String, Object> validateResponse = new LinkedHashMap<String, Object>();

        //解析http请求体
        Map<String, String> params = PayBeanUtils.parse(request.getInputStream());
        
        //cp订单号
        String orderid = params.get("orderid");
        //签名 MD5(orderid=XXX&Key=XXX)
        String signMsg = params.get("signMsg");
        String usercode = params.get("usercode");
        String provinceid = params.get("provinceid");
        String cityid = params.get("cityid");
        
        //校验签名是否正确
        String sign = String.format("orderid=%s&Key=%s", orderid, App.KEY);
        String mySign = MD5.MD5Encode(sign);
        if (mySign.equalsIgnoreCase(signMsg)) {
            //TODO: start 填写校验订单逻辑，需要开发者完成 
            
            /*
             * 如果通过校验，将ifpasswd设置为true
             * 通过校验的含义为，待校验的订单在开发者系统中为有效订单，可以继续支付
             */
            boolean ifpasswd = true;
            
            //TODO: end
            
            if (ifpasswd) {
                //TODO: 通过订单获取必要信息，需开发者完成
                String serviceid = "";
                String feename = "";
                Integer payfee = 0;
                Date ordertime = new Date();
                String gameaccount = "";
                String macaddress = "";
                String ipaddress = "";
                String imei = "";
                String appversion = "";
                //

                //0-验证成功 1-验证失败，必填
                validateResponse.put("checkOrderIdRsp", 0);
                
                //应用名称，必填
                validateResponse.put("appName", App.APP_NAME);
                
                //计费点名称
                validateResponse.put("feename", feename);
                
                //计费点金额，单位分
                validateResponse.put("payfee", payfee);
                
                //应用开发商名称，必填
                validateResponse.put("appdeveloper", App.APP_DEVELOPER);
                
                //游戏账号，长度<=64，联网支付必填
                validateResponse.put("gameaccount", gameaccount);
                
                //MAC地址去掉冒号，联网支付必填，单机尽量上报
                validateResponse.put("macaddress", macaddress);
                
                //沃商店应用id，必填
                validateResponse.put("appid", App.APP_ID);
                
                //IP地址，去掉点号，补零到每地址段3位, 如：192168000001，联网必填，单机尽量
                validateResponse.put("ipaddress", ipaddress);
                
                //沃商店计费点，必填
                validateResponse.put("serviceid", serviceid);
                
                //渠道ID，必填
                validateResponse.put("channelid", App.CHANNEL_ID);
                
                //沃商店CPID，必填
                validateResponse.put("cpid", App.CPID);
                
                //订单时间戳，14位时间格式，联网必填，单机尽量
                validateResponse.put("ordertime", DateFomatter.format(ordertime));
                
                //设备标识，联网必填，单机尽量上报
                validateResponse.put("imei", imei);
                
                //应用版本号，必填
                validateResponse.put("appversion", appversion);
            } else {
                validateResponse.put("checkOrderIdRsp", 1);
            }
        } else {
            validateResponse.put("checkOrderIdRsp", 1);
        }
        
        //将结果返回
        writeResponse(PayBeanUtils.toValidateOrderidResponse(validateResponse), response);
    }

    /**
     * 处理支付结果通知
     * @param request
     * @param response
     * @throws IOException
     */
    private void processPayNotify(HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        
        //订单是否被处理
        boolean fullyProcessed = false;
        
        //解析http请求体
        Map<String, String> params = PayBeanUtils.parse(request.getInputStream());
        
        //cp订单号
        String orderid = params.get("orderid");
        //订单时间
        String ordertime = params.get("ordertime");
        //沃商店cpid
        String cpid = params.get("cpid");
        //应用ID
        String appid = params.get("appid");
        //渠道ID
        String fid = params.get("fid");
        //计费点ID
        String consumeCode = params.get("consumeCode");
        //支付金额，单位分
        String payfee = params.get("payfee");
        //0-沃支付，1-支付宝，2-VAC支付，3-神州付 ...
        String payType = params.get("payType");
        //支付结果，0代表成功，其他代表失败
        String hRet = params.get("hRet");
        //状态码
        String status = params.get("status");
        //签名 MD5(orderid=XXX&ordertime=XXX&cpid=XXX&appid=XXX&fid=XXX&consumeCode=XXX&payfee=XXX&payType=XXX&hRet=XXX&status=XXX&Key=XXX)
        String signMsg = params.get("signMsg");
        
       //校验签名是否正确
        String signPattern = "orderid=%s&ordertime=%s&cpid=%s&appid=%s&fid=%s&consumeCode=%s&payfee=%s&payType=%s&hRet=%s&status=%s&Key=%s";
        String sign = String.format(signPattern, orderid, ordertime, cpid, appid, fid, consumeCode, payfee, payType, hRet, status, App.KEY);
        String mySign = MD5.MD5Encode(sign);
        if (mySign.equalsIgnoreCase(signMsg)) {

            //TODO： start 开发者处理逻辑, 处理完成后，将fullyProcessed设为ture
            
            if ("0".equals(hRet)) {
                //TODO: 添加支付成功逻辑
            } else {
                //TODO: 添加支付失败逻辑
            }
            //
            fullyProcessed = true;
            //
            //
            //TODO: end
            
        }
        
        if (!fullyProcessed) {
            response.setStatus(400);
        }
        
        writeResponse(PayBeanUtils.toPaynotifyResponse(fullyProcessed ? 1 : 0), response);
    }

    /**
     * 将body写入reponse流中
     * @param body
     * @param response
     */
    private void writeResponse(String body, HttpServletResponse response){
        if (body == null || response == null) {
            return;
        }
        try {
            response.setContentType("application/xml;charset=utf-8");
            OutputStream os = response.getOutputStream();
            os.write(body.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
