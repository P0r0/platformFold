package com.unicom.cpdemo.commons;

/**
 * 此类中的参数都可在开发者社区获取
 * 请替换为正式参数
 */
public interface App {

    //沃商店CPID
    static final String CPID = "test";
    
    //计费密钥
    static final String KEY = "test";
    
    //沃商店应用id
    static final String APP_ID = "test";
    
    //应用名称
    static final String APP_NAME = "test";
    
    //开发者名称
    static final String APP_DEVELOPER = "test";
    
    //渠道号
    static final String CHANNEL_ID = "test";
}
