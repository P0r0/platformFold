package com.anzhi.notify.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.anzhi.util.Des3Util;

/**
 * notify支付订单（游戏充值）回调demo
 * @author gbf
 *
 */
public class PayCallBack extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	        this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("notify client-------------------payCallBack");
		System.out.println(request.getParameterMap());
		System.out.println(Des3Util.decrypt(request.getParameter("data"),"5mv85Qa2Yx1Kg1flBhhEfe3d"));
		response.getWriter().print("success");
	}

}
