package com.anzhi.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;

import com.anzhi.util.A_Resp;
import com.anzhi.util.Base64;
import com.anzhi.util.JacksonMapper;


/**
 * notify 查询订单demo
 * @author gbf
 *
 */
public class QueryOrderAction extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
           this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("notify client--------------------------queryOrder");
		String appkey = "c318br6RLex12IeBs0Ta6wo1";
		String tradenum = "20130701180155090";
		String mintradetime = "";
		String maxtradetime = "";
		String appsecret = "5mv85Qa2Yx1Kg1flBhhEfe3d";
		String sign = Base64.encodeToString(appkey+tradenum+mintradetime+maxtradetime+appsecret);
		String time ="20130701120311";
		                                                                                                                               
		HttpClient httpclient = new HttpClient();
		PostMethod post = new PostMethod("http://pay.anzhi.com/web/api/third/1/queryorder");
		String respStr = null;
		post.setRequestHeader("Content-type", "text/xml; charset=UTF-8");
		NameValuePair[] data ={ new NameValuePair("appkey",appkey),new NameValuePair("tradenum",tradenum),new NameValuePair("mintradetime",mintradetime),new NameValuePair("maxtradetime",maxtradetime),new NameValuePair("sign",sign),new NameValuePair("time",time)};
        post.setQueryString(data);
		httpclient.getHostConfiguration().setHost("http://pay.anzhi.com/web/api/third/1/queryorder");
		int result = 0;
		result = httpclient.executeMethod(post);
		if (result == HttpStatus.SC_OK) {
			respStr = post.getResponseBodyAsString();
		}
		System.out.println("queryOrder HttpURLConnection is OK strs:"+respStr);
		A_Resp a = JacksonMapper.readValue(respStr,A_Resp.class);
		System.out.println("msg:"+Base64.decode(a.getMsg(),"UTF-8"));
		response.setContentType("text/html;charset=GBK"); 
		response.getWriter().println(respStr);
		response.getWriter().println("msg: "+Base64.decode(a.getMsg(),"UTF-8"));
	}
}
